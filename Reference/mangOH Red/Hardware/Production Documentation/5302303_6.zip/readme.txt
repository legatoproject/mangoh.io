Design contains NET_JUNCTION. 
Nets "GND" & "PWR_GND_BQ" are intentionally shorted.